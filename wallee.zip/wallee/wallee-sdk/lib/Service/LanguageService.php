<?php
/**
 * wallee SDK
 *
 * This library allows to interact with the wallee payment service.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */



namespace Wallee\Sdk\Service;

use Wallee\Sdk\ApiClient;
use Wallee\Sdk\ApiException;
use Wallee\Sdk\ApiResponse;
use Wallee\Sdk\Http\HttpRequest;
use Wallee\Sdk\ObjectSerializer;

/**
 * LanguageService service
 *
 * @category Class
 * @package  Wallee\Sdk
 * @author   wallee AG
 * @license  http://www.apache.org/licenses/LICENSE-2.0 Apache License v2
 */
class LanguageService {

	/**
	 * The API client instance.
	 *
	 * @var ApiClient
	 */
	private $apiClient;

	/**
	 * Constructor.
	 *
	 * @param ApiClient|null $apiClient the api client
	 */
	public function __construct(?ApiClient $apiClient = null) {
		if (is_null($apiClient)) {
			throw new \InvalidArgumentException('The api client is required.');
		}

		$this->apiClient = $apiClient;
	}

	/**
	 * Returns the API client instance.
	 *
	 * @return ApiClient
	 */
	public function getApiClient() {
		return $this->apiClient;
	}


	/**
	 * Operation all
	 *
	 * Returns the possible languages that the API supports
	 *
	 * @return array
	 */
	public function all() {
		$jsonString = file_get_contents(__DIR__ . '/../languages.json');
		$languageData = $this->apiClient->getSerializer()->deserialize(json_decode($jsonString, true), '\Wallee\Sdk\Model\RestLanguage[]');
		return $languageData;
	}

	/**
	 * Operation allWithHttpInfo
	 *
	 * All
	*
	 * @throws \Wallee\Sdk\ApiException
	 * @throws \Wallee\Sdk\VersioningException
	 * @throws \Wallee\Sdk\Http\ConnectionException
	 * @return ApiResponse
	 */
	public function allWithHttpInfo() {
		// header params
		$headerParams = [];
		$headerAccept = $this->apiClient->selectHeaderAccept(['application/json;charset=utf-8']);
		if (!is_null($headerAccept)) {
			$headerParams[HttpRequest::HEADER_KEY_ACCEPT] = $headerAccept;
		}
		$headerParams[HttpRequest::HEADER_KEY_CONTENT_TYPE] = $this->apiClient->selectHeaderContentType(['*/*']);

		// query params
		$queryParams = [];

		// path params
		$resourcePath = '/language/all';
		// default format to json
		$resourcePath = str_replace('{format}', 'json', $resourcePath);

		// form params
		$formParams = [];
		
		// for model (json/xml)
		$httpBody = '';
		if (isset($tempBody)) {
			$httpBody = $tempBody; // $tempBody is the method argument, if present
		} elseif (!empty($formParams)) {
			$httpBody = $formParams; // for HTTP post (form)
		}
		// make the API Call
		try {
			$response = $this->apiClient->callApi(
				$resourcePath,
				'GET',
				$queryParams,
				$httpBody,
				$headerParams,
				'\Wallee\Sdk\Model\RestLanguage[]',
				'/language/all'
			);
			return new ApiResponse($response->getStatusCode(), $response->getHeaders(), $this->apiClient->getSerializer()->deserialize($response->getData(), '\Wallee\Sdk\Model\RestLanguage[]', $response->getHeaders()));
		} catch (ApiException $e) {
			switch ($e->getCode()) {
			 case 200:
				$data = ObjectSerializer::deserialize(
					$e->getResponseBody(),
					'\Wallee\Sdk\Model\RestLanguage[]',
					$e->getResponseHeaders()
				);
				$e->setResponseObject($data);
			 break;
			 case 442:
				$data = ObjectSerializer::deserialize(
					$e->getResponseBody(),
					'\Wallee\Sdk\Model\ClientError',
					$e->getResponseHeaders()
				);
				$e->setResponseObject($data);
			 break;
			 case 542:
				$data = ObjectSerializer::deserialize(
					$e->getResponseBody(),
					'\Wallee\Sdk\Model\ServerError',
					$e->getResponseHeaders()
				);
				$e->setResponseObject($data);
			 break;
			}
			throw $e;
		}
	}
}
