# PrestaShop 9 wallee Integration
This repository contains the PrestaShop wallee payment module that enables the shop to process payments with [wallee](https://www.wallee.com).

To install module manually by dragging up zip file, please download [.zip archive](@WalleeDocPath(/wallee.zip)) of module with correct structure required by Prestashop installation

##### To use this extension, a [wallee](https://app-wallee.com/user/signup) account is required.

## Requirements

* [PrestaShop](https://www.prestashop.com/) 9
* [PHP](http://php.net/) 9.0 (minimum PHP version supported by Prestashop 9 version)

## Documentation

* [English](@WalleeDocPath(/docs/en/documentation.html))

## Support

Support queries can be issued on the [wallee support site](https://app-wallee.com/space/select?target=/support).

## Supported versions

____________________________________________________________________________
| Prestashop version   | Plugin major version | Supported until        |
|------------------------|----------------------|------------------------|
| 9.0.x -                | 2.x                  | Further notice         |
| 8.0.x - 8.2.x          | 1.x                  | Further notice         |
----------------------------------------------------------------------------

## License

Please see the [license file](@WalleeRepoPath(/LICENSE)) for more information.

## Other PrestaShop Versions

Find the module for different PrestaShop versions [here](../../../prestashop).
